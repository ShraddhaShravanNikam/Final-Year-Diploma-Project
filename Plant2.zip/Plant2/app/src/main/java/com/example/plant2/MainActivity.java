package com.example.plant2;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.plant2.databinding.ActivityMainBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView  bnview;
   Button web1,web2,web3,web4,web5,web6,web7,web8;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        web1=findViewById(R.id.button3);
        web2=findViewById(R.id.button16);
        web3=findViewById(R.id.button15);
        web4=findViewById(R.id.button8);
        web5=findViewById(R.id.button7);
        web6=findViewById(R.id.button6);
        web7=findViewById(R.id.button5);
        web8=findViewById(R.id.button4);
        web1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotourl("https://agriculture.vic.gov.au/biosecurity/plant-diseases/grain-pulses-and-cereal-diseases/leaf-rust-of-wheat#:~:text=Like%20the%20other%20rusts%20it,significant%20impact%20on%20grain%20yield.");
            }
        });

        web2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotourl("https://www.nature-and-garden.com/gardening/diseases-rose-tree.html");
            }
        });

        web3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotourl("https://vikaspedia.in/agriculture/crop-production/integrated-pest-managment/ipm-for-spice-crops/ipm-strategies-for-ginger/diseases-and-symptoms");
            }
        });

        web4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //soya
                gotourl("https://www.ndsu.edu/agriculture/ag-hub/publications/soybean-disease-diagnostic-series");
            }
        });

        web5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotourl("https://agritech.tnau.ac.in/crop_protection/tomato_diseases_12.html");
            }
        });

        web6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotourl("https://vikaspedia.in/agriculture/crop-production/integrated-pest-managment/ipm-for-commercial-crops/ipm-strategies-for-sugarcane/sugarcane-diseases-and-symptoms");
            }
        });

        web7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotourl("https://hgic.clemson.edu/factsheet/tomato-diseases-disorders/");
            }
        });

        web8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotourl("https://vikaspedia.in/agriculture/crop-production/integrated-pest-managment/ipm-for-fruit-crops/ipm-strategies-for-apple/apple-diseases-and-symptoms");
            }
        });

        ((ImageView) findViewById(R.id.arr)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, home.class));
            }
        });




    }


void gotourl(String s)
{
 try {
     Uri uri= Uri.parse(s);
     startActivity(new Intent(Intent.ACTION_VIEW,uri));
 }
 catch (Exception e)
 {

     Toast.makeText(getApplicationContext(),"no website linked",Toast.LENGTH_SHORT).show();
 }
}
}