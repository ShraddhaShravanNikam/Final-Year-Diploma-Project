package com.example.plant2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class home extends AppCompatActivity {
ImageView web1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        web1=findViewById(R.id.imageView12);


        ((ImageView) findViewById(R.id.imageView11)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {startActivity(new Intent(home.this,Species.class));
            }
        });


        ((ImageView) findViewById(R.id.imageView13)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(home.this, profile.class));
            }
        });

        ((ImageView) findViewById(R.id.imageView14)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(home.this, Fruit.class));
            }
        });

        ((ImageView) findViewById(R.id.imageView15)).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(home.this, Flower.class));
                    }
        });

        ((ImageView) findViewById(R.id.imageView20)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(home.this, Camera.class));
            }
        });
        ((ImageView) findViewById(R.id.imageView16)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(home.this, bud.class));
            }
        });

        ((ImageView) findViewById(R.id.imageView17)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(home.this, leaf.class));
            }
        });
        ((ImageView) findViewById(R.id.imageView18)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(home.this, stem.class));
            }
        });
        ((ImageView) findViewById(R.id.imageView19)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(home.this, root.class));
            }
        });

        web1=findViewById(R.id.imageView12);

        web1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotourl("https://docs.google.com/forms/u/0/d/e/1FAIpQLSePCxqfI7c0GeLLnLdCQAZzNSOVCMz681qfVr7JDd-OvhtdrA/viewform?usp=send_form&pli=1");
            }
        });


    }
    void gotourl(String s)
    {
        try {
            Uri uri= Uri.parse(s);
            startActivity(new Intent(Intent.ACTION_VIEW,uri));
        }
        catch (Exception e)
        {

            Toast.makeText(getApplicationContext(),"no website linked",Toast.LENGTH_SHORT).show();
        }
    }
}
