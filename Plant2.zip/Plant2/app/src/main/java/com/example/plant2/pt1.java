package com.example.plant2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class pt1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pt1);
    }
}