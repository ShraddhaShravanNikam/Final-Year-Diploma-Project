package com.example.plant2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Species extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_species);

        ((ImageView) findViewById(R.id.i1)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, bamboo1.class));
            }
        });



        ((ImageView) findViewById(R.id.i2)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, suger1.class));
            }
        });
        ((ImageView) findViewById(R.id.i3)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, mazze1.class));
            }
        });

        ((ImageView) findViewById(R.id.i4)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, pea1.class));
            }
        });

        ((ImageView) findViewById(R.id.i5)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, pot1.class));
            }
        });
        ((ImageView) findViewById(R.id.i6)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, ginger1.class));
            }
        });

        ((ImageView) findViewById(R.id.i7)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, baj.class));
            }
        });



        ((ImageView) findViewById(R.id.i8)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, gahu1.class));
            }
        });
        ((ImageView) findViewById(R.id.i10)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, har1.class));
            }
        });

        ((ImageView) findViewById(R.id.i11)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, cor1.class));
            }
        });

        ((ImageView) findViewById(R.id.i12)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, shepu1.class));
            }
        });
        ((ImageView) findViewById(R.id.uniq)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Species.this, jawar.class));
            }
        });

    }
}